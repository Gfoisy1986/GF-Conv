import Graphics.UI.Gtk
import Control.Monad (void)
import qualified Data.Text as T
import Control.Monad.IO.Class (liftIO)

main :: IO ()
main = do
    -- Initialize GTK
    void initGUI

    -- Create a new window
    window <- windowNew
    set window [windowTitle := "Unit Converter", containerBorderWidth := 10, windowDefaultWidth := 300]

    -- Create combo boxes for units
    fromCombo <- comboBoxNewText
    mapM_ (comboBoxAppendText fromCombo . T.pack) ["Meters", "Kilometers", "Miles", "Inches", "Pounds", "Feet"]

    toCombo <- comboBoxNewText
    mapM_ (comboBoxAppendText toCombo . T.pack) ["Meters", "Kilometers", "Miles", "Inches", "Pounds", "Feet"]

    -- Create an entry for the value to convert
    entry <- entryNew

    -- Create a button for conversion
    convertButton <- buttonNewWithLabel "Convert"

    -- Create a label to display the result
    resultLabel <- labelNew (Nothing :: Maybe String)

    -- Pack everything into a vertical box
    vbox <- vBoxNew False 10
    boxPackStart vbox fromCombo PackGrow 0
    boxPackStart vbox toCombo PackGrow 0
    boxPackStart vbox entry PackGrow 0
    boxPackStart vbox convertButton PackGrow 0
    boxPackStart vbox resultLabel PackGrow 0
    containerAdd window vbox

    -- Connect signals
    on window deleteEvent $ liftIO mainQuit >> return False

    on convertButton buttonActivated $ do
        -- Get the selected units
        fromUnit <- comboBoxGetActiveText fromCombo
        toUnit <- comboBoxGetActiveText toCombo

        -- Get the input value
        inputValue <- entryGetText entry
        let value = read inputValue :: Double

        -- Perform the conversion
        let convertedValue = convertUnits value (maybe "" T.unpack fromUnit) (maybe "" T.unpack toUnit)

        -- Display the result
        labelSetText resultLabel (show convertedValue)

    -- Show all widgets
    widgetShowAll window

    -- Start the GTK main loop
    mainGUI

-- Dummy conversion function
convertUnits :: Double -> String -> String -> Double
convertUnits value fromUnit toUnit
    | fromUnit == "Inches" && toUnit == "Feet" = value / 12
    | fromUnit == "Feet" && toUnit == "Inches" = value * 12
    | fromUnit == "Pounds" && toUnit == "Kilograms" = value * 0.453592
    | fromUnit == "Kilograms" && toUnit == "Pounds" = value / 0.453592
    | otherwise = value -- Just return the input value for unsupported conversions
